#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

FILE *fp;

char delim[] = {' ', '\t', '\n', ',', ';', '(', ')', '{', '}', '[', ']', '#', '<', '>'};
char keywords[][10] = {
    "int", "float", "char", "double", "bool", "void", "extern", "unsigned", "goto",
    "static", "class", "struct", "for", "if", "else", "return", "register", "long", "while", "do"
};
char predict[2][12] = {"include", "define"};
char header[6][15] = {"stdio.h", "conio.h", "malloc.h", "process.h", "string.h", "ctype.h"};

void skipcomment();
void analyze();
void check(char[]);
int isdelim(char);
int isop(char);

char c, ch;
int fop = 0, numflag = 0, f = 0;
char sop;

int main()
{
    char fname[100];
    printf("\nEnter filename: ");
    scanf("%s", fname);
    fp = fopen(fname, "r");

    if (fp == NULL)
    {
        printf("\nThe file does not exist.\n");
        return 1;
    }
    else
    {
        analyze();
    }

    printf("\nEnd of file\n");
    fclose(fp);
    return 0;
}

void analyze()
{
    char token[256];
    int j = 0;

    while ((c = getc(fp)) != EOF)
    {
        if (c == '/')
        {
            skipcomment();
        }
        else if (isdelim(c))
        {
            if (j != 0)
            {
                token[j] = '\0';
                check(token);
                j = 0;
                numflag = 0;
            }
            if (c != ' ' && c != '\t' && c != '\n')
                printf("\nDelimiter \t%c", c);
        }
        else if (isalpha(c) || c == '_')
        {
            token[j++] = c;
        }
        else if (isdigit(c))
        {
            token[j++] = c;
            numflag = 1;
        }
        else if (isop(c))
        {
            if (j != 0)
            {
                token[j] = '\0';
                check(token);
                j = 0;
                numflag = 0;
            }
            printf("\nOperator \t%c", c);
        }
        else if (c == '.')
        {
            token[j++] = c; // maybe a float number
        }
        else
        {
            if (j != 0)
            {
                token[j] = '\0';
                check(token);
                j = 0;
                numflag = 0;
            }
        }
    }

    if (j != 0)
    {
        token[j] = '\0';
        check(token);
    }
}

int isdelim(char c)
{
    for (int i = 0; i < sizeof(delim); i++)
    {
        if (c == delim[i])
            return 1;
    }
    return 0;
}

int isop(char c)
{
    if (c == '+' || c == '-' || c == '*' || c == '/' || c == '=' || c == '<' || c == '>')
        return 1;
    return 0;
}

void check(char t[])
{
    int i;
    if (numflag == 1)
    {
        printf("\nNumber \t\t%s", t);
        return;
    }
    for (i = 0; i < 2; i++)
    {
        if (strcmp(t, predict[i]) == 0)
        {
            printf("\nPreprocessor directive \t%s", t);
            return;
        }
    }
    for (i = 0; i < 6; i++)
    {
        if (strcmp(t, header[i]) == 0)
        {
            printf("\nHeader file \t%s", t);
            return;
        }
    }
    for (i = 0; i < 20; i++) // corrected to 20 keywords
    {
        if (strcmp(t, keywords[i]) == 0)
        {
            printf("\nKeyword \t\t%s", t);
            return;
        }
    }
    printf("\nIdentifier \t%s", t);
}

void skipcomment()
{
    ch = getc(fp);
    if (ch == '/')
    {
        // Single line comment
        while ((ch = getc(fp)) != '\n' && ch != EOF)
            ;
    }
    else if (ch == '*')
    {
        // Multi-line comment
        while (1)
        {
            ch = getc(fp);
            if (ch == '*')
            {
                if ((ch = getc(fp)) == '/')
                    break;
                else
                    ungetc(ch, fp);
            }
            if (ch == EOF)
                break;
        }
    }
    else
    {
        ungetc(ch, fp);
    }
}



/*note:
gcc lex.c -o lex
./lex

Enter fileneame: text.txt*/
